﻿Get-recipient | select name -ExpandProperty EmailAdresses | Select Name, Smtpaddress
