﻿Get-AdObject -Properties mail, proxyaddresses -Filter {mail -like "*tecalliance.net" -or proxyAddresses -like "smtp:*tecalliance*"}


Get-Mailbox | sort-object SamAccountName | Select-Object SamAccountName,PrimarySmtpAddress | export-csv c:\temp\samaccounts_with_smtp.csv
