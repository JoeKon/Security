﻿
Get-Module -ListAvailable

Get-PSSnapin -Registered

Add-PSSnapin Microsoft.Exchange.Managment.PowerShell.E2010


Get-recipient | select name -ExpandProperty EmailAdresses | Select Name, Smtpaddress
