﻿Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010

Get-Recipient -Filter {EmailAddresses -like "*tecalliance*"}


