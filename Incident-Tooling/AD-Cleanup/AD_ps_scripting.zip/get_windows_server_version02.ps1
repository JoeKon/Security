﻿#JKON 080721
# get Server-Version
#https://sid-500.com/2019/07/30/powershell-retrieve-list-of-domain-computers-by-operating-system/
#
#Retrieve all Windows Server Computer
Get-ADComputer -Filter 'operatingsystem -like "*server*" -and enabled -eq "true"' `
-Properties Name,Operatingsystem,OperatingSystemVersion,IPv4Address |
Sort-Object -Property Operatingsystem |
Select-Object -Property Name,Operatingsystem,OperatingSystemVersion,IPv4Address
##
##Retrieve all Domain-Controllers (no Member-Server)
Get-ADComputer -Filter 'primarygroupid -eq "516"' `
-Properties Name,Operatingsystem,OperatingSystemVersion,IPv4Address |
Sort-Object -Property Operatingsystem |
Select-Object -Property Name,Operatingsystem,OperatingSystemVersion,IPv4Address | ConvertTo-Html | Out-File C:\Temp\listDCcontroler.htm
##
##Retrieve all Member-Server
Get-ADComputer -Filter 'operatingsystem -like "*server*" -and enabled -eq "true" -and primarygroupid -ne "516"' `
-Properties Name,Operatingsystem,OperatingSystemVersion,IPv4Address |
Sort-Object -Property Operatingsystem |
Select-Object -Property Name,Operatingsystem,OperatingSystemVersion,IPv4Address | Out-GridView
##
##

