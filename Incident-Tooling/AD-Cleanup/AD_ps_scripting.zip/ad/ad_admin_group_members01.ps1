﻿#Get-Module -Listavailable
# Ad-Auswertung administrative user-groups
# ad_admin_group_members01.ps1

Get-AdGroupMember -identity ROL-O-ADM_Admins  | Select Name, SamAccountName | Format-Table –AutoSize | Export-csv -path C:\temp\ROL-O-ADM_Admins.txt
Get-AdGroupMember -identity Domänen-Admins  | Select Name, SamAccountName | Format-Table –AutoSize | Export-csv -path C:\temp\Domänen-Admins.txt
Get-AdGroupMember -identity ROL-A-CA_Vorlagen_Admin  | Select Name, SamAccountName | Format-Table –AutoSize | Export-csv -path C:\temp\ROL-A-CA_Vorlagen_Admin.txt
Get-AdGroupMember -identity ROL-O-VMWARE_Benutzer  | Select Name, SamAccountName | Format-Table –AutoSize | Export-csv -path C:\temp\ROL-O-VMWARE_Benutzer.txt
Get-AdGroupMember -identity ROL-O-CPI-ADMINS  | Select Name, SamAccountName | Format-Table –AutoSize | Export-csv -path C:\temp\ROL-O-CPI-ADMINS.txt

Get-AdGroupMember -identity ROL-O-SQL-GENSRV_Admins  | Select Name, SamAccountName | Format-Table –AutoSize >> C:\temp\ROL-O-SQL-GENSRV_Admins.txt


#Auflistung all Administrative Groups with elevated rights: 
#Domänen-Admins #-- Administratoren der Domäne

#ROL-A-CA_Vorlagen_Admin #-- KEINE BEschreibung! -> CA-Verwaltung!?

#ROL-A-TecAlliance_Administrator   #-- Domänen Admins Vollzugriffe aus fast alle Ordner

#ROL-O-CPI-ADMINS #-- Rollengruppe, die es den Mitgliedern erlaubt auf der CPI administrative arbeiten durchzuführen

#ROL-O-VMWARE_Benutzer #-- Rollengruppe VMWARE vCenter Berechtigung Benutzer

#Organization Management #-- Members of this management role group have permissions to manage Exchange objects and their properties in the Exchange organization. Members can also delegate role groups and management roles in the organization. This role group shouldn't be deleted.

#ROL-O-CTX_HelpdeskAdmin #-- Rollengruppe Ctitrix Director Zugriff

#ROL-O-DFS_Laufwerke #-- Anzeige von DFS TA_Data$ und TA_Config$

#ROL-O-SCCM_Users #-- ruppe um vorhandene SCCM Funktionen zu verwalten

#ROL-O-WLAN_User #-- Gruppe WLAN User Köln
#ROL-O-All_Special_Accounts_TecAlliance #-- Mitglied der ROL-O-All_Employees_TecAlliance von TimeTac Sync ausgeschlossen

#Get-AdGroupMember -identity “ROL-O-ADM_Admins” | select name
#Get-ADGroupMember -identity “ROL-O-ADM_Admins” | select name | Export-csv -path C:\temp\filename.csv -NoTypeInformation
#Get-ADGroupMember -Identity "Domain Admins" | Select Name, SamAccountName


