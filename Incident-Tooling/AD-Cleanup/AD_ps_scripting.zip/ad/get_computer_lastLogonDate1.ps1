﻿#get-recipient | select name -ExpandProperty EmailAdresses | select Name, Smtpaddress

get-adcomputer -Identity S-SV-VEPRTGPRO1 -Properties LastLogonDate

Test-NetConnection S-SV-VEPRTGPRO1