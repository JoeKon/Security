﻿## jkon 17.09.21
## dnszone_cleanup-NS-records1.ps1
## from https://mxrnz.wordpress.com/2016/08/24/dns-remove-ns-records-powershell/
##
# define NS-name to be deleted
#$myDNSServer = "w-sv-vedc05.tec.dom."
$myDNSServer = "dc02.audacon.com."
#$myDNSServer = "dc03.audacon.com."


##Get-DnsServerZone | %($Name = $_zonename , 'Get-DnsServerResourceRecord' -ZoneName $_zonename -RRType 'Ns' | ?{$_RecordData.NameServer -like "*w-sv-vedc05.tec.dom*"}  | fl
##Get-DnsServerZone | %{$Name = $_.zonename ; Get-DnsServerResourceRecord -ZoneName $_.zonename -RRType ‘NS’} | fl

#show info where the entry actually included in
Get-DnsServerZone | %{$Name = $_.zonename ; Get-DnsServerResourceRecord -ZoneName $_.zonename -RRType ‘NS’} | ?{$_.RecordData.NameServer -like “*$myDNSServer*”} | fl

#remove recursivly all NS records
Get-DnsServerZone | %{$Name = $_.zonename ; Get-DnsServerResourceRecord -ZoneName $_.zonename -RRType ‘NS’ | ?{$_.RecordData.NameServer -like “*$myDNSServer*”} | Remove-DnsServerResourceRecord -ZoneName $name}
