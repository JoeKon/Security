﻿## DD RMI AD-Group Reports

Get-AdGroupMember -identity ROL-O-SQL-GENSRV_Admins  | Select Name, SamAccountName | Format-Table –AutoSize >> C:\temp\ROL-O-SQL-GENSRV_Admins.txt


Get-AdGroupMember -identity ROL-O-Data_Processing_RMI_WKH  | Select Name, SamAccountName | Format-Table –AutoSize >> C:\temp\ROL-O-Data_Processing_RMI_WKH.txt
Get-AdGroupMember -identity ROL-O-SQL-WKH-Report_Liefer-Daten-SD-DataProcessingTecRMI  | Select Name, SamAccountName | Format-Table –AutoSize >> C:\temp\ROL-O-SQL-WKH-Report_Liefer.txt

