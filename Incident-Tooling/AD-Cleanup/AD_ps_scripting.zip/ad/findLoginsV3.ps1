### ###################################################################################
### Script to locate successful logins for specific users (i.e. Service accounts).
###
###
### TODO:
### + Paralelize script across domain controllers
###     -Local run !! DONE via Remote PSSession
### + Logontype array to define in Human Readable format !! DONE
### + Add code to fuse csvs into one. !! DONE
### + Send file to a share !! DONE
### + Start-End Time? (If DCs protocol more than 24hours)
### + change yesterday to startdate !! DONE
#######################################################################################


Import-Module ActiveDirectory

### Grab a list of Domain Controllers for later.
$DCs = Get-ADDomainController -Filter *

### Allow the user to filter logs for a specific Username. Without DOM\
### Use if interactive script
$SAMAccountName = @("svc-backup", "intern", "svc-na-snapdrive", "svc-chreq", "Administrator")

### Show only results since Yesterday.
$startDate = (Get-Date).AddDays(-1)

### Get Todays date
$today = get-date -Format "ddMMyyyy-HHmm"

### Define Logontypes for final output
$logonTypes = @("0", "1", "Interactive", "Network", "Batch", "Service", "6", "Unlock", "NetworkCleartext", "NewCredentials", "RemoteInteractive", "CachedInteractive")

## Grab each DC Separate and pass through Remote Powershell commands
## so that each DC may scan their own Event Logs.
## This is to save time.

foreach ($DC in $DCs) {
#if ($DC.Hostname -notlike "C-SV-VEDC03.TEC.DOM") {
    Write-Host "Entering $($DC.Hostname)...`n"
    $session = New-PSSession $DC.Hostname

    ## Invoke a Remote Powershell Command to scan WinEvent Logs
    ## Sorts through for specific User defined in $SAMAccountName
    ## Exports to CSV and stores on a share.

    Invoke-Command -Session $session -ScriptBlock {
        
        ### Get local values needed for scriptblock.
        ### This fixes some bugs in naming the csv 

        $remLogonTypes = $Using:logonTypes
        $remToday = $Using:today
        $remStartDate = $Using:startDate
        $remSAMAccountName = $Using:SAMAccountName

        Get-WinEvent -FilterHashTable @{Logname='security';ID=4624} | 
        Select-Object -Property TimeCreated,
        @{Name='LogonType';Expression={$remLogonTypes[$_.Properties[8].Value]}},
        @{Name='AccountName';Expression={$_.Properties[5].Value}},
        @{Name='AccountDomain';Expression={$_.Properties[6].Value}},
        @{Name='Workstation';Expression={$_.Properties[11].Value}},
        @{Name='IPAddress';Expression={$_.Properties[18].Value}},
        @{Name="Hostname";Expression={[System.Net.Dns]::GetHostByAddress(($_.Properties[18].Value)).Hostname}},
        @{Name='DomainController';Expression={$env:computername}} | 
        Where {$remSAMAccountName -contains $_.AccountName -and $_.TimeCreated -ge $remStartDate } | Export-Csv -Path "\\c-sv-veadmin\c$\Temp\exportLogins\serviceUserExport$($remToday)-$($env:computername).csv" -Delimiter "," -Force -NoClobber -Encoding UTF8 -NoTypeInformation
    }

    Write-Host "Exiting $($DC.Hostname)...`n"
#}
}