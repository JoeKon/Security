
#         install-module -name vmware.powercli -AllowClobber
#         Set-PowerCLIConfiguration -Scope AllUsers -ParticipateInCeip $false -InvalidCertificateAction Ignore

Import-Module VMware.PowerCLI

$vserver = "c-sv-vevc03"
$exportPath = "C:\scripts\exports\export-$($vserver)-$(get-date -format "ddMM-HHmm").csv"

Add-Content $exportPath "ComputerName;DNS1;DNS2"

Connect-VIServer -Server $vserver -credential (get-credential)
$vms = get-vm

foreach ($vm in $vms) {
  $computer = $vm.Name
  try {
   $Networks = Get-WmiObject -Class Win32_NetworkAdapterConfiguration `
       -Filter IPEnabled=TRUE `
       -ComputerName $Computer `
       -ErrorAction Stop
   } catch {
    Write-Verbose "Failed to Query $Computer. Error details: $_"
    continue
  }
  
  foreach($Network in $Networks) {
      $DNSServers = $Network.DNSServerSearchOrder
      $NetworkName = $Network.Description
     If(!$DNSServers) {
      $PrimaryDNSServer = "Notset"
      $SecondaryDNSServer = "Notset"
     } elseif($DNSServers.count -eq 1) {
      $PrimaryDNSServer = $DNSServers[0]
      $SecondaryDNSServer = "Notset"
     } else {
      $PrimaryDNSServer = $DNSServers[0]
      $SecondaryDNSServer = $DNSServers[1]
    }
  }
    Add-Content $exportPath "$Computer;$PrimaryDNSServer;$SecondaryDNSServer"
}

Disconnect-VIServer -Server $vserver -Confirm:$false