###
### RUN ONCE A DAY TO AVOID OVERWRITING FILES
###

$today = Get-Date -Format "ddMMyyyy-HHmm"

$getFirstLine = $false
mkdir "\\c-sv-veadmin\c$\Temp\exportLogins\$($today)"

get-childItem "\\c-sv-veadmin\c$\Temp\exportLogins\*.csv" | foreach {
    $filePath = $_

    $lines =  $lines = Get-Content $filePath  
    $linesToWrite = switch($getFirstLine) {
           $true  {$lines}
           $false {$lines | Select -Skip 1}

    }

    $getFirstLine = $false
    Add-Content "\\c-sv-veadmin\c$\Temp\exportLogins\merged\serviceUserExport$($today).csv" $linesToWrite
    Move-Item -Path $filePath -Destination "\\c-sv-veadmin\c$\Temp\exportLogins\$($today)"
    }