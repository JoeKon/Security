﻿## 16.09.21  remove old dns server in dns zone
##

$myDNSServer = "w-sv-vedc05.tec.dom."

#$PDCE = (Get-ADDomainController -Discover -Service PrimaryDC)
$PDCE = "w-sv-vedc.tec.dom"
$DNSZones = Get-DnsServerZone -ComputerName $PDCE

foreach($aZone in $DNSZones)
{ 
   $ZoneName = $aZone.ZoneName
   $RRs = Get-DnsServerResourceRecord -ZoneName $ZoneName -Name "@" -RRType NS -ComputerName $PDCE
   foreach ($rr in $RRs)
   {
    if ($rr.RecordData -eq $myDNSServer)
    {
        write-host $rr
        $rr | Remove-DnsServerResourceRecord -computername $PDCE -WhatIf
     }
   }
   #write "Remove-DnsServerResourceRecord -ZoneName $ZoneName -RRType Ns -RecordData $myDNSServer -ComputerName $PDCE -Force"
   ## Remove-DnsServerResourceRecord -ZoneName $ZoneName -RRType Ns -RecordData $myDNSServer -ComputerName $PDCE -Force
}
