﻿Search-ADAccount -lockedOut | Select Name, UserPrincipalName, SamAccountName, LastLogonDate, LockedOut, PasswordExpired, PasswordNeverExpires


(get-addomain).pdcemulator