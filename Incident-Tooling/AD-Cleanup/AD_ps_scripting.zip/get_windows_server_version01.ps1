﻿#JKON 080721
# get Server-Version
#
Get-ADComputer -SearchBase 'OU=ADMINISTRATION,DC=tec,DC=dom' -Filter * -Properties * | FT Name, OperatingSystem, OperatingSystemServicePack, OperatingSystemVersion -Wrap -Auto


# show server version
Get-ADComputer -SearchBase 'OU=ADMINISTRATION,DC=tec,DC=dom' -Filter {OperatingSystem -Like "Windows *Server*"} -Property * | Format-Table Name,OperatingSystem,OperatingSystemServicePack -Wrap -Auto

Get-ADComputer -SearchBase 'OU=ADMINISTRATION,DC=tec,DC=dom' -Filter {OperatingSystem -Like "Windows *Server 2016*"} -Property * | Format-Table Name,OperatingSystem,OperatingSystemServicePack -Wrap -Auto

Get-ADComputer -SearchBase 'OU=ADMINISTRATION,DC=tec,DC=dom' -Filter {OperatingSystem -Like "Windows *Server 2019*"} -Property * | Format-Table Name,OperatingSystem,OperatingSystemServicePack -Wrap -Auto

# export to CSV
#Get-ADComputer -SearchBase 'OU=ADMINISTRATION,DC=tec,DC=dom' -Filter {OperatingSystem -Like "Windows *Server 2019*"} -Property * | Format-Table Name,OperatingSystem,OperatingSystemServicePack -Wrap -Auto | Export-CSV c:\temp\GetWindows2019.csv -NoTypeInformation -Encoding UTF8
Get-ADComputer -SearchBase 'OU=ADMINISTRATION,DC=tec,DC=dom' -Filter {OperatingSystem -Like "Windows *Server 2019*"} -Property * | Format-Table Name,OperatingSystem,OperatingSystemServicePack >> c:\temp\GetWindows2019.txt

Get-ADComputer -SearchBase 'OU=ADMINISTRATION,DC=tec,DC=dom' -Filter {OperatingSystem -Like "Windows *Server 2016*"} -Property * | Format-Table Name,OperatingSystem,OperatingSystemServicePack >> c:\temp\GetWindows2016.txt 
