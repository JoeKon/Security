### $ErrorActionPreference="SilentlyContinue"

# List of DCs from AD
### $DCs = Get-ADDomainController -Filter *
### Speed up by restricting DCs
$dc1 = Get-ADDomainController -Identity "c-sv-vedc03.tec.dom"
$DCs = @($dc1)
$log = 'Security'

# Result: List of events
$events = @()
# Result: List of events by DC
$DCevents = @{}

# Store successful logon events from security logs with the specified dates and workstation/IP in an array
foreach ($DC in $DCs) {
    write-host "Searching security log on " $DC.HostName
	#$e = Get-WinEvent -LogName Security -ComputerName $DC.Hostname -FilterHashTable $filter | where {$_.eventID -eq 4624 }
	$e = Get-WinEvent -LogName "$log" -ComputerName $DC.Hostname | where-Object { $_.EventID -eq 4624 } | ft
    #$e | ft
    $DCEvents.Add($DC, $es)
    $events += $e
}

# Crawl through events; print all logon history with type, date/time, status, account name, computer and IP address if user logged on remotely
foreach ($e in $events) {

	# Logon Successful Events

	# Local (Logon Type 2)
	if ($e.ReplacementStrings[8] -eq 2) {
		write-host "Type: Interactive Logon`tDate: " $e.TimeGenerated "`tStatus: Success`tUser: " $e.ReplacementStrings[5] "`tWorkstation: "$e.ReplacementStrings[11]
	}

	# Batch (Logon Type 4)
	if ($e.ReplacementStrings[8] -eq 4) {
		write-host "Type: Batch Logon`tDate: " $e.TimeGenerated "`tStatus: Success`tUser: " $e.ReplacementStrings[5] "`tWorkstation: "$e.ReplacementStrings[11]
	}

	# Service (Logon Type 5)
	if ($e.ReplacementStrings[8] -eq 8) {
		write-host "Type: Service Logon`tDate: " $e.TimeGenerated "`tStatus: Success`tUser: " $e.ReplacementStrings[5] "`tWorkstation: "$e.ReplacementStrings[11]
	}

	# Remote (Logon Type 10)
	if ($e.ReplacementStrings[8] -eq 10) {
		write-host "Type: Remote Logon`tDate: "$e.TimeGenerated "`tStatus: Success`tUser: "$e.ReplacementStrings[5] "`tWorkstation: "$e.ReplacementStrings[11] "`tIP Address: "$e.ReplacementStrings[18]
	}
}
