﻿Get-ADComputer -Filter * -Properties * | 
    Where-Object { $_.DnsHostname -like "W-SV-VESQLT02.TEC.DOM" -and $_.OperatingSystem -like "Windows Server *" -and $_.Enabled -eq $true -and $_.IPv4Address.Length -ge 7 } |
    Sort-Object DnsHostName |
    ForEach-Object {
        $hostname = $_.DnsHostName
        $ip = $_.IPv4Address
        $os = $_.OperatingSystem
        $created = $_.whenCreated
        "$hostname `t $ip `t $os `t $created`n"
        Invoke-Command -ComputerName $hostname -ScriptBlock {
            Get-NetAdapter  -Physical | Where-Object { $_.status -eq "up" } | Format-Table -AutoSize
            Get-DnsClientServerAddress -AddressFamily IPv4 | Select-Object InterfaceAlias,ServerAddresses | Format-Table -AutoSize
        }
        "--------------------------------------------------------------------------------"
    }
