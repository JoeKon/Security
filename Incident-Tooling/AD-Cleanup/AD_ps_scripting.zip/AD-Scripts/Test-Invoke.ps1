﻿Get-ADComputer -Filter * -Properties * | 
    Where-Object { $_.OperatingSystem -like "Windows Server*" -and $_.Enabled -eq $true -and $_.IPv4Address.Length -ge 7 } |
    Sort-Object DnsHostName |
    ForEach-Object {
        $hostname = $_.DnsHostName
        $ip = $_.IPv4Address
        $os = $_.OperatingSystem
        $created = $_.whenCreated
        "$hostname `t $ip `t $os `t $created`n"
        Invoke-Command -ComputerName $hostname -ScriptBlock {
            " "
        }
        "--------------------------------------------------------------------------------"
    }
