﻿$cs = Import-Csv -Path computers.txt
$cs | ForEach-Object {
    $name = $_.dnshostname
    $ip = $_.ipv4address
    if ($ip -like "10.202.*") {
        Write-Output "$name ( $ip )"
        Invoke-Command -ComputerName $name -ScriptBlock {
            if (-not (Test-ComputerSecureChannel -Verbose)) {
               Test-ComputerSecureChannel -Repair
            }
        } | Select-String -Pattern "TEC.DOM"
        Write-Output "----------------------------------------------------------------------------"
    }
}
