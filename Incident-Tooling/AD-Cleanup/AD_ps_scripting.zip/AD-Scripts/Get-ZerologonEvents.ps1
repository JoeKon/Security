﻿$dcs = Get-ADDomainController -Filter *
$dcs | ForEach-Object {
    $_.Name
    Invoke-Command -ComputerName $_.Name -HideComputerName -ScriptBlock {
        Get-EventLog -LogName 'System' -InstanceId 5827,5828,5829,5830,5831 | Format-List
    }
    "--------------------------------------------------------------------------------"
}
