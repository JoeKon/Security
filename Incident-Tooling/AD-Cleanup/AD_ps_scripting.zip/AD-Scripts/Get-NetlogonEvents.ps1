﻿$hostname = hostname
Get-EventLog -LogName System -Source NetLogon -After '2020-09-18'
