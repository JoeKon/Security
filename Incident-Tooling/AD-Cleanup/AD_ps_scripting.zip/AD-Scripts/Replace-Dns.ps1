﻿$cgn = "172.30.*"; $cgnumb = "172.30.2.217", "172.30.2.218", "10.111.100.210"
$wk0 = "10.110.*.*"; $wk0umb = "10.111.100.210", "10.111.100.211", "172.30.2.218"
$wkh = "10.111.*.*"; $wkhumb = "10.111.100.210", "10.111.100.211", "172.30.2.218"
$elp = "10.112.*.*"; $elpumb = "10.111.100.210", "10.111.100.211", "172.30.2.218"
$muc = "10.202.*.*"; $mucumb = "10.202.100.226", "10.202.100.227", "172.30.2.218"
$mst = "10.10.*.*"; $mstumb = "10.10.95.210", "10.10.95.211", "172.30.2.218"
$csh = "10.86.*.*"; $cshumb = "10.86.100.210", "10.86.100.211", "172.30.2.218"
$tfn = "10.0.*.*"; $tfnumb = "10.0.100.110", "10.0.100.111", "172.30.2.218"

($cgnumb -join ",")
$cgndns

Get-DnsClientServerAddress -AddressFamily IPv4 |
ForEach-Object {
    if ( $_.ServerAddresses.Count -gt 0 ) {
        $ifa = $_.InterfaceAlias
        $ifdns = $_.ServerAddresses[0]
        if ( $ifdns -like $cgn ) { $dns = $cgnumb -join "," }
        if ( $ifdns -like $wk0 ) { $dns = $wk0umb -join "," }
        if ( $ifdns -like $wkh ) { $dns = $wkhumb -join "," }
        if ( $ifdns -like $elp ) { $dns = $elpumb -join "," }
        if ( $ifdns -like $muc ) { $dns = $mucumb -join "," }
        if ( $ifdns -like $mst ) { $dns = $mstumb -join "," }
        if ( $ifdns -like $csh ) { $dns = $cshumb -join "," }
        if ( $ifdns -like $tfn ) { $dns = $tfnumb -join "," }
        $dns = "($dns)"
        $_ | fl
        Set-DnsClientServerAddress -InterfaceAlias $ifa -ServerAddresses $dns
    }
}
Get-DnsClientServerAddress -AddressFamily IPv4 | ft

#netsh interface ipv4 add dnsserver "%INTERFACE%" %DNS1%
#netsh interface ipv4 add dnsserver "%INTERFACE%" %DNS2% index=2