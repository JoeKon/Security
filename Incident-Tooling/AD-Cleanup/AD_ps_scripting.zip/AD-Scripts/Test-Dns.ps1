﻿#Get-ADComputer -Identity M-SV-VHDFS05 -Properties * | 
Get-ADComputer -Filter * -Properties * | 
    Where-Object { $_.OperatingSystem -like "Windows Server 201*" -and $_.Enabled -eq $true -and $_.IPv4Address.Length -ge 7 } |
    Sort-Object DnsHostName |
    ForEach-Object {
        $hostname = $_.DnsHostName
        $ip = $_.IPv4Address
        $os = $_.OperatingSystem
        $created = $_.whenCreated
        "$hostname `t $ip `t $os `t $created`n"
        Invoke-Command -ComputerName $hostname -ScriptBlock {
            Get-DnsClientServerAddress -AddressFamily IPv4 | Select-Object InterfaceAlias,ServerAddresses | Format-Table
        }
        "--------------------------------------------------------------------------------"
    }
