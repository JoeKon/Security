﻿Get-ADComputer -Identity c-sv-vedhcp -Properties * | Where-Object { $_.OperatingSystem -like "Windows Server*" } |
    ForEach-Object {
        Invoke-Command -ComputerName $_.DnsHostName -ScriptBlock {
            winrm quickconfig -quiet
        }
    }
