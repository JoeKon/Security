﻿Get-ADComputer -Filter * -Properties * | Where-Object { $_.OperatingSystem -like "Windows Server*" } |
    ForEach-Object {
        Invoke-Command -ComputerName $_.DnsHostName -ScriptBlock {
            Get-DnsClientServerAddress -AddressFamily IPv4 |
                Where-Object { $_.InterfaceAlias -like "Ether*" -and $_.ServerAddresses.Count -gt 0 }
        }
    }
