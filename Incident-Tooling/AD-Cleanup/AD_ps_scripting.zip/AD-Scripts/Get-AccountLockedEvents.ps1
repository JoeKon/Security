﻿Write-Output "#Script created 2020-09-26 by ext-pk"
Write-Output "#Format: CSV (tab separated)"
Write-Output "DateTime        `tComputerName`tAccountName"
$pdc = (Get-ADDomain).PdcEmulator
Invoke-Command -ComputerName $pdc -ScriptBlock {
    $hostname = hostname
    Get-EventLog -LogName 'Security' -InstanceId 4740 | 
    ForEach-Object {
        $date = $_.TimeGenerated
        $user = $_.ReplacementStrings[0]
        $computer = $_.ReplacementStrings[1]
        Write-Output "$date`t$computer`t$user"
    }
}
