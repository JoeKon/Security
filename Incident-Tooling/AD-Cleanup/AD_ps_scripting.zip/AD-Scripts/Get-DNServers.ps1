﻿Get-ADDomainController -Filter * |
    ForEach-Object {
        Invoke-Command -ComputerName $_.Hostname -ScriptBlock {
            Get-DnsClientServerAddress -AddressFamily IPv4 |
                Where-Object { $_.InterfaceAlias -like "Ether*" -and $_.ServerAddresses.Count -gt 0 }
        }
    }
