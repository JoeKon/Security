﻿Invoke-Command -ComputerName c-sv-vedc -ScriptBlock {
    Get-ADReplicationPartnerMetadata -Target "$env:userdnsdomain" -Scope Domain |
    Select-Object Server, LastReplicationAttempt, LastReplicationSuccess
} |
Format-Table
