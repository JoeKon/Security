# -------------------------------------------------------------------------------
if ( $false ) {

Get-ADComputer -Properties dnsHostname,ipv4address,operatingSystem,lastLogonTimestamp,enabled -Filter { operatingSystem -like "Windows Server*" -and enabled -eq $true } |
Where-Object { $_.ipv4address.Count -gt 0  } |
Sort-Object dnshostname |
Select-Object dnshostname,ipv4address,operatingsystem,lastlogontimestamp |
ForEach-Object {
    $obj = $_
    $obj.lastlogontimestamp = (Get-Date '1601-01-01').AddDays([long]::Parse($obj.lastlogontimestamp)*100/86400/1000/1000/1000)
    $obj
} |
Export-Csv computers.txt

}
# -------------------------------------------------------------------------------
if ( $false ) {

import-csv computers.txt | ForEach-Object {
    "`n"
    ping -4 -n 1 $_.dnshostname
}

}
# -------------------------------------------------------------------------------
if ( $true ) {

import-csv computers.txt | ForEach-Object {
    "`n"
    Invoke-Command -ComputerName $_.dnshostname -ScriptBlock { Get-DnsClientServerAddress } | ft
}

}
# -------------------------------------------------------------------------------
if ( $false ) {

"`n"
$NetAdapter = Get-NetAdapter | Where-Object {$_.Status -eq 'up' -and $_.MacAddress -like '00-50-56-*' }
"-- NETWORK ADAPTERS"
$NetAdapter | ft

"-- IP ADDRESSES"
$NetIpAddress = Get-NetIPAddress -InterfaceIndex $NetAdapter.ifIndex
$NetIpAddress | ft

try {
"-- TEST CONNECTION"
#$output = Test-NetConnection $NetIpAddress.IpAddress -InformationLevel Detailed
$output = Test-NetConnection 10.86.0.80 -InformationLevel Detailed
$output | ft
}
catch {
"Error: unreachable"
}

"-- DNS CLIENT"
$DnsClient = Get-DnsClientServerAddress -InterfaceIndex $NetAdapter.ifIndex -AddressFamily 'IPv4'
$DnsClient | ft

}
# -------------------------------------------------------------------------------
if ($false) {

$computers = import-csv computers.txt
$computers | foreach-object {
	"`n" *>&1
	"========================================================" *>&1
	$_.dnshostname *>&1
	"========================================================" *>&1
        ping $_.dnshostname *>&1
	Invoke-Command -ComputerName $_.dnshostname -ScriptBlock { Get-NetIPAddress -AddressFamily IPv4 -SuffixOrigin Manual } *>&1
	#test-connection $_.dnshostname *>&1
} | tee computers.log

}
# -------------------------------------------------------------------------------
if ($false) {

$computers = import-csv computers.txt
$computers | foreach-object {
	"`n" *>&1
	"========================================================" *>&1
	$_.dnshostname *>&1
	"========================================================" *>&1
        ping -4 -n 1 $_.dnshostname *>&1
	"`n" *>&1
	Invoke-Command -ComputerName $_.dnshostname -ScriptBlock { Get-NetIPAddress -AddressFamily IPv4 } | ft *>&1
	"`n" *>&1
	Invoke-Command -ComputerName $_.dnshostname -ScriptBlock { Get-DnsClientServerAddress -AddressFamily IPv4 } | ft *>&1
} | tee computers2.log.txt

}
# -------------------------------------------------------------------------------
