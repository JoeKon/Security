﻿$dcs = Get-ADDomainController -Filter *
$dcs | ForEach-Object {
    $_.Name
    Invoke-Command -ComputerName $_.Name -HideComputerName -ScriptBlock {
        Get-WinEvent -LogName 'Directory Service' | 
        Where-Object { $_.Id -eq 2889 } |
        Format-List
    }
    "--------------------------------------------------------------------------------"
}
