﻿## <https://docs.microsoft.com/en-us/powershell/module/activedirectory/move-addirectoryserver?view=windowsserver2022-ps> 

Move-ADDirectoryServer -Identity "w-sv-vedc02" -Site "Site-TEST"

## Site-Weikersheim
# Move-ADDirectoryServer -Identity "w-sv-vedc02" -Site "Site-Weikersheim"
