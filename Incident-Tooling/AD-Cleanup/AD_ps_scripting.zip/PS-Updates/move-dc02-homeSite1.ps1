﻿## move-dc02-homeSite1.ps1
## <https://docs.microsoft.com/en-us/powershell/module/activedirectory/move-addirectoryserver?view=windowsserver2022-ps> 
# JKON 11.03.22

# move DC02 to home-Site after Maintenance/Update

## Site-TEST
##Move-ADDirectoryServer -Identity "w-sv-vedc02" -Site "Site-TEST"

## Site-Cologne
Move-ADDirectoryServer -Identity "c-sv-vedc02" -Site "Site-Cologne"

## Site-Munich
Move-ADDirectoryServer -Identity "m-sv-vedc02" -Site "Site-Munich"

## Site-Weikersheim
Move-ADDirectoryServer -Identity "w-sv-vedc02" -Site "Site-Weikersheim"
