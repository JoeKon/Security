﻿# WSUS Clients not reporting
# wsus_clientReporting-reset1.ps1
#
#Remove the affected devices from the WSUS MMC console 
#and then from an administrative PowerShell prompt on each affected system
#https://www.ajtek.ca/wsus/client-machines-not-reporting-to-wsus-properly/


Stop-Service -Name BITS, wuauserv -Force
Remove-ItemProperty -Name AccountDomainSid, PingID, SusClientId, SusClientIDValidation -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\ -ErrorAction SilentlyContinue
Remove-Item "$env:SystemRoot\SoftwareDistribution\" -Recurse -Force -ErrorAction SilentlyContinue
Start-Service -Name BITS, wuauserv
wuauclt /resetauthorization /detectnow
(New-Object -ComObject Microsoft.Update.AutoUpdate).DetectNow()
