﻿$u = Invoke-Command -ComputerName w-sv-vedc01 -ScriptBlock `
{Start-WUScan -SearchCriteria "UpdateId='<GUID-des-Updates>' AND IsInstalled=1"} `
-Credential jkon.ga0

$cs = New-CimSession -ComputerName w-sv-vedc01 -Credential Credential admin\contoso

Install-WUUpdates -Updates $u -DownloadOnly -CimSession $cs

Install-WUUpdates -Updates $u -CimSession $cs

Get-WUIsPendingReboot

w-sv-vedc01



Install-Module PSWindowsUpdate -MaximumVersion 1.5.2.6
Get-Command -Module PSWindowsUpdate

Invoke-WUInstall -ComputerName w-sv-vedc01,e-sv-phdc01 -Script {ipmo PSWindowsUpdate; Get-WUInstall -AcceptAll | Out-File C:\
PSWindowsUpdate.log } -Confirm:$false -Verbose 