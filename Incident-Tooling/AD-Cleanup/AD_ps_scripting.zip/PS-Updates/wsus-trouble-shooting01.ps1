﻿
#https://arnaudloos.com/2019/wsus-troubleshooting/
#WSUS Troubleshooting Steps 

# PC mdlets available for WSUS
Get-Command -Module UpdateServices


### for WSUS Servers ###
# to detect missing patches
usoclient.exe startscan
#  to refresh settings if any changes were made
usoclient.exe refreshsettings
# to download patches
usoclient.exe startdownload
# to install patches
usoclient.exe startinstall


#### for WSUS Clients ####
(New-Object -ComObject Microsoft.Update.AutoUpdate).DetectNow()




# test wsus server connectivity
Test-NetConnection -ComputerName w-sv-vewsus01.tec.dom -Port 8531 -InformationLevel Detailed

