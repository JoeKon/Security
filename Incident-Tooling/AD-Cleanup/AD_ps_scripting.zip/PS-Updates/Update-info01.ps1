﻿# update infos

Get-SilWindowsUpdate -Verbose

Get-WindowsUpdateLog -Verbose

notepad  C:\Users\jkon.ga\Desktop\WindowsUpdate.log
