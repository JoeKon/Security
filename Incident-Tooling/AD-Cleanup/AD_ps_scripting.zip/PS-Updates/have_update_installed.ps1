#Finding Computers that already have installed a special Hotfix
(Get-ADComputer -Filter *).Name | Foreach-Object {If ((Get-Hotfix -ID "KB5009557" -ComputerName $_ -ErrorAction SilentlyContinue)) {Add-Content $_ -Path C:\Temp\already_5009557.txt}}


## have not !  
##(Get-ADComputer -Filter *).Name | Foreach-Object {If (!(Get-Hotfix -ID "KB5009557" -ComputerName $_ -ErrorAction SilentlyContinue)) {Add-Content $_ -Path C:\Temp\already_5009557.txt}}
