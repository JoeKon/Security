﻿# show details to certificate with several filter strings
clear

# filter exiry after X days
Get-ChildItem -Recurse | where { $_.notafter -le (get-date).AddDays(75) -AND $_.notafter -gt (get-date)} | select thumbprint, subject

#
Get-ChildItem -Path Microsoft.PowerShell.Security\Certificate::CurrentUser\My | fl NotAfter
Get-ChildItem -Path Microsoft.PowerShell.Security\Certificate::CurrentUser\My | select NotAfter, subject, thumbprint


# filter exiry after X days showing Date, subject, thumbprint
Get-ChildItem -Path Microsoft.PowerShell.Security\Certificate::CurrentUser\My -ExpiringInDays 75 -verbose 
Get-ChildItem -Path Microsoft.PowerShell.Security\Certificate::CurrentUser\My -ExpiringInDays 75 -verbose | select NotAfter, subject, thumbprint



Get-ChildItem -Path Microsoft.PowerShell.Security\Certificate::CurrentUser\My | where { $_.notafter -le (get-date).AddDays(75) -AND $_.notafter -gt (get-date)} | select thumbprint, subject

# filter strings Name
Get-ChildItem -Path Microsoft.PowerShell.Security\Certificate::CurrentUser\My | where { $_.Subject -match 'JKON' }
#
Get-ChildItem -Path Microsoft.PowerShell.Security\Certificate::CurrentUser\My | where { $_.Subject -match 'JKON' } | select NotAfter, thumbprint, subject
#

Get-ChildItem -Path Microsoft.PowerShell.Security\Certificate::CurrentUser\My | where { $_.notafter -le (get-date).AddDays(75) -AND $_.notafter -gt (get-date)} | select NotAfter, thumbprint, subject

Get-ChildItem -Path Certificate::CurrentUser\ -Recurse | where { $_.notafter -le (get-date).AddDays(75) } | select NotAfter, thumbprint, subject


# filter strings Name, tecalliance, partners
gci -Path Microsoft.PowerShell.Security\Certificate::CurrentUser\My | Where {$_.Subject –match 'hermos'} | select NotAfter, subject, thumbprint
gci -Path Microsoft.PowerShell.Security\Certificate::CurrentUser\My | Where {$_.Subject –match 'partners'} | select NotAfter, subject, thumbprint
gci -Path Microsoft.PowerShell.Security\Certificate::CurrentUser\My | Where {$_.Subject –match 'tecalliance'} | select NotAfter, subject, thumbprint

# CA Information remote
Invoke-Command -ComputerName "C-SV-VECA.tec.dom" -ScriptBlock {Get-ChildItem -Path Certificate::CurrentUser\ -Recurse -ExpiringInDays 120} | select NotAfter, subject, thumbprint

Invoke-Command -ComputerName "C-SV-VECA.tec.dom" -ScriptBlock {Get-ChildItem -Path Certificate::CurrentUser\ -Recurse -ExpiringInDays 120 | select NotAfter, subject, thumbprint }
