﻿##get_adUser_lastLogin02.ps1
##https://www.tecklyfe.com/using-powershell-get-user-last-logon-date/

#Import-Module ActiveDirectory

function Get-ADUserLastLogon([string]$userName)
{
$dcs = Get-ADDomainController -Filter {Name -like "*"}
$time = 0
foreach($dc in $dcs)
{
$hostname = $dc.HostName
$user = Get-ADUser $userName -Server $hostname | Get-ADObject -Properties lastLogon
if($user.LastLogon -gt $time)
{
$time = $user.LastLogon
}
}
$dt = [DateTime]::FromFileTime($time)
Write-Host $username "last logged on at:" $dt }

##Write-Host $username "last logged on at:" $dt $hostname }
##Write-Host $username "last logged on '$hostname' at:" $dt }
## wrong?! - result for hostname is always "euce1DC01p.TEC.DOM2
## >> c:\temp\adm_login.csv
## | Select Name, SamAccountName | Format-Table –AutoSize | Export-csv -path C:\temp\adm_login.csv

Get-ADUserLastLogon -UserName adm-jko 
Get-ADUserLastLogon -UserName adm-fde
Get-ADUserLastLogon -UserName adm-ws
Get-ADUserLastLogon -UserName adm-ph
Get-ADUserLastLogon -UserName adm-tkle
Get-ADUserLastLogon -UserName adm-om
