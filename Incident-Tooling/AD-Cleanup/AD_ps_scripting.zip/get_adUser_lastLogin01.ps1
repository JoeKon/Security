﻿##get_adUser_lastLogin01.ps1

Get-ADUser  adm-jko | -Properties lastlogondate

Get-ADUser -Identity adm-jko -Properties * | select *logon*  

Get-ADUser -Identity adm-jko -Properties * | select *  | Select Name, SamAccountName, LastLogonDate  | Format-Table –AutoSize 