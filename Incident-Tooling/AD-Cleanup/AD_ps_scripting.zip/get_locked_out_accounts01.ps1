﻿#locked out AD Accounts
#Search-ADAccount -AccountExpired
#Search-ADAccount -AccountDisabled
#Search-ADAccount -AccountInactive

#Get-ADComputer -Filter * -Property MemberOf | Where-Object {​​​$_.Name -like "*w-sv*"}​​​ | where-object {​​​[string]$_.memberof -notlike "*ROL-O-HW_Notebooks*"}​​​ | select name


#-Properties * | Select-Object SamAccountName, LockedOut

Search-ADAccount –LockedOut -Verbose

Get-ADUser jkon -Properties * | Select-Object SamAccountName, LockedOut

Get-ADUser svc-prtg-tier0 -Properties * | Select-Object SamAccountName, LockedOut
Get-ADUser svc-prtg-tier1 -Properties * | Select-Object SamAccountName, LockedOut
Get-ADUser svc-prtg-tier2 -Properties * | Select-Object SamAccountName, LockedOut

#Search-ADAccount –LockedOut | Where-Object {​​​ADAccount -like "*svc-prtg-*"}​​​ 

#Get-ADUser svc-prtg-* -Properties * | Select-Object SamAccountName, LockedOut