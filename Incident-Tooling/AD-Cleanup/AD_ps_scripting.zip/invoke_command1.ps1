﻿Invoke-Command -ComputerName m-lp-2165 -ScriptBlock { gpupdate }

Invoke-Command -ComputerName c-lp-2204.tec.dom -ScriptBlock { gpupdate }


Invoke-Command -ComputerName euce1adfs01p -ScriptBlock { gpupdate }


Invoke-Command -ComputerName w-lp-0782 -ScriptBlock { gpupdate }

Invoke-Command -ComputerName m-lp-2125  -ScriptBlock { gpupdate }

 m-lp-2125

 Invoke-Command -ComputerName c-lp-2032  -ScriptBlock { gpupdate }


 Invoke-Command -ComputerName w-lp-0588 -ScriptBlock { gpupdate }