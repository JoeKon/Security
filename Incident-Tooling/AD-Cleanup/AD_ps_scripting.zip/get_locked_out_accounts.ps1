﻿#locked out AD Accounts
#


#-Properties * | Select-Object SamAccountName, LockedOut

Search-ADAccount –LockedOut

Get-ADUser jkon -Properties * | Select-Object SamAccountName, LockedOut

Get-ADUser svc-prtg-tier0 -Properties * | Select-Object SamAccountName, LockedOut
Get-ADUser svc-prtg-tier1 -Properties * | Select-Object SamAccountName, LockedOut
Get-ADUser svc-prtg-tier2 -Properties * | Select-Object SamAccountName, LockedOut

Search-ADAccount –LockedOut | where 

