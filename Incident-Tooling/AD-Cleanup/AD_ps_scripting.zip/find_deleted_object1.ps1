﻿Beispielsweise würde man einen gelöschten Benutzer "John Doe" mit dem Befehl

Get-ADObject -Filter {displayName -eq "John Doe"} –IncludeDeletedObjects

ermitteln und mit

Get-ADObject -Filter {displayName -eq "John Doe"} –IncludeDeletedObjects |
Restore-ADObject