﻿##get_folder_access_Groups01.ps1
## JKON 03.05.21

(get-acl T:\InformationMgmt_TecRMI\Technical_Manuals).access | ft IdentityReference,FileSystemRights,AccessControlType,IsInherited,InheritanceFlags -auto

