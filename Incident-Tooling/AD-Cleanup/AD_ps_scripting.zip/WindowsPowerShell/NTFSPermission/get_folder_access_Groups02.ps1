﻿##get_folder_access_Groups02.ps1
##JKON 03.05.21

#$FolderPath = dir -Directory -Path "T:\WKH_EXC\Clearing\Watch" ##-Recurse -Force

$FolderPath = dir -Directory -Path "T:\InformationMgmt_TecRMI\Technical_Manuals" ##-Recurse -Force
$Report = @()
Foreach ($Folder in $FolderPath) {
    $Acl = Get-Acl -Path $Folder.FullName
    foreach ($Access in $acl.Access)
        {
            $Properties = [ordered]@{'FolderName'=$Folder.FullName;'AD
Group or
User'=$Access.IdentityReference;'Permissions'=$Access.FileSystemRights;'Inherited'=$Access.IsInherited}
            $Report += New-Object -TypeName PSObject -Property $Properties
        }
}
$Report | Export-Csv -path "C:\temp\FolderPermissionsTM.csv"