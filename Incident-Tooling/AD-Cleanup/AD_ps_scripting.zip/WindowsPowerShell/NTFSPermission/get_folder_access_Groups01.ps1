﻿##get_folder_access_Groups01.ps1
## JKON 03.05.21

(get-acl T:\WKH_EXC\Clearing\Watch).access | ft IdentityReference,FileSystemRights,AccessControlType,IsInherited,InheritanceFlags -auto

