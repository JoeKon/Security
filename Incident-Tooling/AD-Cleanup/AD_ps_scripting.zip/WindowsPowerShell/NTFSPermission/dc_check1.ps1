﻿Get-ADDomainController

Get-ADDomainController -Filter * | ft


get-dcsinforest

get-dcinforest -referenceDomain tec.dom

